import { createFileRoute } from "@tanstack/react-router";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ — Everly Finds" },
      { name: "description", content: "Answers to common questions about shipping, returns, sizing, and orders at Everly Finds." },
      { property: "og:title", content: "FAQ — Everly Finds" },
      { property: "og:description", content: "Shipping, returns, sizing, and order questions." },
    ],
  }),
  component: FAQ,
});

const items = [
  { q: "How long does shipping take?", a: "Standard orders ship within 1–3 business days and typically arrive in 7–14 business days worldwide. You'll receive a tracking number as soon as your order leaves our fulfillment partner." },
  { q: "Do you ship internationally?", a: "Yes. We ship to most countries. Local duties and taxes are calculated at checkout where applicable." },
  { q: "What's your return policy?", a: "You can return unused items in original packaging within 30 days of delivery for a refund of the item price. Return shipping is customer-paid unless the item arrived defective." },
  { q: "How do I pick the right size?", a: "Every product page lists dimensions and, where relevant, sizing notes. If you're between sizes, we generally recommend sizing up." },
  { q: "Can I change or cancel my order?", a: "We can change or cancel orders within 12 hours of purchase. After that, they enter fulfillment and can't be modified." },
  { q: "How can I contact you?", a: "Email hello@everlyfinds.example or use our Contact page. We respond within one business day." },
];

function FAQ() {
  return (
    <div className="container-page py-16 md:py-24 max-w-3xl">
      <p className="text-xs uppercase tracking-[0.2em] text-accent">Help</p>
      <h1 className="font-display text-4xl md:text-5xl mt-3">Frequently asked</h1>
      <Accordion type="single" collapsible className="mt-10">
        {items.map((it, i) => (
          <AccordionItem key={i} value={`item-${i}`}>
            <AccordionTrigger className="text-left text-base">{it.q}</AccordionTrigger>
            <AccordionContent className="text-muted-foreground leading-relaxed">{it.a}</AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}
