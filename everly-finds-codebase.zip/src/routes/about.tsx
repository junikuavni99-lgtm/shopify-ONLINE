import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Everly Finds" },
      { name: "description", content: "Everly Finds curates pet, home, and fitness essentials from vetted global partners." },
      { property: "og:title", content: "About — Everly Finds" },
      { property: "og:description", content: "Curated everyday objects, chosen with care." },
    ],
  }),
  component: About,
});

function About() {
  return (
    <div className="container-page py-16 md:py-24 max-w-3xl">
      <p className="text-xs uppercase tracking-[0.2em] text-accent">Our story</p>
      <h1 className="font-display text-4xl md:text-6xl mt-3">Small shop, high standards.</h1>
      <div className="mt-8 space-y-6 text-muted-foreground leading-relaxed">
        <p>
          Everly Finds started with a simple frustration: too much stuff, too little joy.
          We built a small shop for the things we actually reach for — the leash that doesn't tangle,
          the pet bowl that slows the meal down, the mat that survives daily practice.
        </p>
        <p>
          We don't manufacture products ourselves. We source from vetted global partners,
          test in our own homes, and only publish what earns a permanent spot. If it works
          for our pets, our floors, and our knees, it works here.
        </p>
        <p>
          Every order is packed and shipped through our fulfillment partners, typically
          within 1–3 business days. We keep our team lean so we can keep prices honest.
        </p>
      </div>
    </div>
  );
}
