import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery, queryOptions } from "@tanstack/react-query";
import { fetchProducts } from "@/lib/shopify";
import { ProductCard } from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { ArrowRight, Truck, ShieldCheck, RefreshCcw, Sparkles } from "lucide-react";
import { Suspense } from "react";

const productsQO = queryOptions({
  queryKey: ["products", "home"],
  queryFn: () => fetchProducts(12),
});

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Everly Finds — Curated everyday objects" },
      { name: "description", content: "Curated pet, home, and fitness essentials. Thoughtfully picked, worldwide shipping." },
      { property: "og:title", content: "Everly Finds — Curated everyday objects" },
      { property: "og:description", content: "Curated pet, home, and fitness essentials. Thoughtfully picked, worldwide shipping." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(productsQO),
  component: Home,
});

function Home() {
  return (
    <>
      <Hero />
      <ValueProps />
      <Suspense fallback={<GridSkeleton />}>
        <FeaturedGrid />
      </Suspense>
      <EditorialBand />
      <NewsletterBand />
    </>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="container-page pt-14 pb-16 md:pt-24 md:pb-24 grid gap-10 md:grid-cols-2 items-center">
        <div>
          <span className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-accent">
            <Sparkles className="h-3.5 w-3.5" /> New arrivals weekly
          </span>
          <h1 className="mt-4 font-display text-5xl md:text-7xl leading-[1.02]">
            Objects worth<br /><em className="text-accent not-italic">living with.</em>
          </h1>
          <p className="mt-5 max-w-md text-muted-foreground">
            A curated shop of pet, home, and movement essentials — chosen for how they feel in the hand and hold up over time.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Button asChild size="lg" className="rounded-full">
              <Link to="/products">Shop the collection <ArrowRight className="ml-2 h-4 w-4" /></Link>
            </Button>
            <Button asChild size="lg" variant="ghost" className="rounded-full">
              <Link to="/about">Our story</Link>
            </Button>
          </div>
        </div>
        <div className="relative">
          <div className="aspect-[4/5] rounded-3xl bg-accent/10 overflow-hidden relative">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,oklch(0.62_0.16_40/0.35),transparent_60%)]" />
            <div className="absolute inset-6 rounded-2xl bg-background/60 backdrop-blur-sm border border-border p-6 flex flex-col justify-end">
              <p className="font-display text-2xl">Warm neutrals.<br />Everyday utility.</p>
              <p className="mt-2 text-sm text-muted-foreground">Curated for pets, home, and movement.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function ValueProps() {
  const items = [
    { icon: Truck, title: "Worldwide shipping", desc: "Tracked delivery, typically 7–14 days." },
    { icon: ShieldCheck, title: "Secure checkout", desc: "Powered by Shopify. Encrypted end-to-end." },
    { icon: RefreshCcw, title: "30-day returns", desc: "Not right? Send it back within 30 days." },
  ];
  return (
    <section className="border-y border-border bg-secondary/40">
      <div className="container-page py-8 grid gap-6 sm:grid-cols-3">
        {items.map(({ icon: Icon, title, desc }) => (
          <div key={title} className="flex items-start gap-3">
            <div className="h-10 w-10 rounded-full bg-background flex items-center justify-center border border-border">
              <Icon className="h-4 w-4 text-accent" />
            </div>
            <div>
              <p className="font-medium text-sm">{title}</p>
              <p className="text-xs text-muted-foreground">{desc}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function FeaturedGrid() {
  const { data: products } = useSuspenseQuery(productsQO);
  if (!products.length) {
    return (
      <section className="container-page py-20 text-center">
        <p className="text-muted-foreground">No products found. Add products in your Shopify admin.</p>
      </section>
    );
  }
  return (
    <section className="container-page py-16 md:py-24">
      <div className="flex items-end justify-between mb-8">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-accent">Featured</p>
          <h2 className="font-display text-3xl md:text-4xl mt-2">Everyone's picks</h2>
        </div>
        <Link to="/products" className="text-sm underline-offset-4 hover:underline">View all →</Link>
      </div>
      <div className="grid gap-x-5 gap-y-10 grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        {products.slice(0, 8).map((p) => (
          <ProductCard key={p.node.id} product={p} />
        ))}
      </div>
    </section>
  );
}

function GridSkeleton() {
  return (
    <section className="container-page py-16">
      <div className="grid gap-5 grid-cols-2 md:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="aspect-square rounded-xl bg-muted animate-pulse" />
        ))}
      </div>
    </section>
  );
}

function EditorialBand() {
  return (
    <section className="container-page py-16 md:py-24">
      <div className="rounded-3xl bg-primary text-primary-foreground p-10 md:p-16 grid md:grid-cols-2 gap-8 items-center">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-accent">Ethos</p>
          <h2 className="font-display text-3xl md:text-5xl mt-3">
            Fewer things.<br />Chosen with care.
          </h2>
        </div>
        <p className="text-primary-foreground/80 max-w-lg">
          We test every item before it enters the shop. If it doesn't earn a place in our own homes, it doesn't earn one in the catalog.
          Everything ships from vetted global partners so you get thoughtful goods, delivered without the markup.
        </p>
      </div>
    </section>
  );
}

function NewsletterBand() {
  return (
    <section className="container-page pb-24">
      <div className="rounded-3xl bg-secondary p-10 md:p-14 text-center">
        <h2 className="font-display text-3xl md:text-4xl">Get 10% off your first order</h2>
        <p className="mt-2 text-muted-foreground max-w-md mx-auto">
          Join the list for early access to new drops and members-only picks.
        </p>
        <form className="mt-6 flex flex-col sm:flex-row gap-2 max-w-md mx-auto" onSubmit={(e) => e.preventDefault()}>
          <input
            type="email"
            required
            placeholder="you@example.com"
            className="flex-1 h-12 rounded-full border border-input bg-background px-5 text-sm outline-none focus:ring-2 focus:ring-ring"
          />
          <Button type="submit" size="lg" className="rounded-full">Subscribe</Button>
        </form>
      </div>
    </section>
  );
}
