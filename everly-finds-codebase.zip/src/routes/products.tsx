import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery, queryOptions } from "@tanstack/react-query";
import { fetchProducts } from "@/lib/shopify";
import { ProductCard } from "@/components/ProductCard";
import { z } from "zod";

const searchSchema = z.object({
  q: z.string().optional(),
});

function productsQO(q?: string) {
  return queryOptions({
    queryKey: ["products", "all", q ?? ""],
    queryFn: () => fetchProducts(50, q || undefined),
  });
}

export const Route = createFileRoute("/products")({
  head: () => ({
    meta: [
      { title: "Shop all — Everly Finds" },
      { name: "description", content: "Browse the full Everly Finds catalog — curated pet, home, and fitness essentials." },
      { property: "og:title", content: "Shop all — Everly Finds" },
      { property: "og:description", content: "Browse the full Everly Finds catalog." },
    ],
  }),
  validateSearch: searchSchema,
  loaderDeps: ({ search: { q } }) => ({ q }),
  loader: ({ context, deps }) => context.queryClient.ensureQueryData(productsQO(deps.q)),
  component: ProductsPage,
});

const FILTERS = [
  { label: "All", q: undefined },
  { label: "Pets", q: "pet" },
  { label: "Fitness", q: "fitness OR workout OR abdominal OR pilates OR yoga" },
  { label: "Home", q: "home OR bowl OR pillow OR trash" },
  { label: "Gadgets", q: "smart OR projector OR camera OR led" },
];

function ProductsPage() {
  const { q } = Route.useSearch();
  const { data: products } = useSuspenseQuery(productsQO(q));

  return (
    <div className="container-page py-10 md:py-16">
      <header className="max-w-2xl">
        <p className="text-xs uppercase tracking-[0.2em] text-accent">Collection</p>
        <h1 className="font-display text-4xl md:text-5xl mt-2">Shop all</h1>
        <p className="mt-3 text-muted-foreground">
          {products.length} {products.length === 1 ? "product" : "products"} · curated for everyday use.
        </p>
      </header>

      <div className="mt-8 flex flex-wrap gap-2">
        {FILTERS.map((f) => {
          const active = (q ?? "") === (f.q ?? "");
          return (
            <Link
              key={f.label}
              to="/products"
              search={f.q ? { q: f.q } : {}}
              className={`px-4 py-1.5 rounded-full text-sm border transition-colors ${
                active
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border hover:border-foreground"
              }`}
            >
              {f.label}
            </Link>
          );
        })}
      </div>

      {products.length === 0 ? (
        <div className="py-24 text-center text-muted-foreground">
          <p>No products found.</p>
        </div>
      ) : (
        <div className="mt-10 grid gap-x-5 gap-y-10 grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {products.map((p) => (
            <ProductCard key={p.node.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
