import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery, queryOptions } from "@tanstack/react-query";
import { fetchProductByHandle, formatPrice, type ShopifyProduct } from "@/lib/shopify";
import { Button } from "@/components/ui/button";
import { useCartStore } from "@/stores/cartStore";
import { useMemo, useState } from "react";
import { Loader2, ShoppingBag, Truck, RefreshCcw, ShieldCheck, ChevronLeft } from "lucide-react";
import { toast } from "sonner";

function productQO(handle: string) {
  return queryOptions({
    queryKey: ["product", handle],
    queryFn: async () => {
      const p = await fetchProductByHandle(handle);
      if (!p) throw notFound();
      return p;
    },
  });
}

export const Route = createFileRoute("/product/$handle")({
  loader: ({ context, params }) => context.queryClient.ensureQueryData(productQO(params.handle)),
  head: ({ loaderData }) => {
    const p = loaderData;
    const title = p ? `${p.title} — Everly Finds` : "Product — Everly Finds";
    const desc = p?.description?.slice(0, 155) || "Curated product at Everly Finds.";
    const img = p?.images.edges[0]?.node.url;
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        ...(img ? [
          { property: "og:image", content: img },
          { name: "twitter:image", content: img },
        ] : []),
      ],
    };
  },
  component: ProductPage,
});

function ProductPage() {
  const { handle } = Route.useParams();
  const { data: product } = useSuspenseQuery(productQO(handle));
  return <ProductView product={product} />;
}

function ProductView({ product }: { product: ShopifyProduct["node"] }) {
  const variants = product.variants.edges.map((e) => e.node);
  const [variantId, setVariantId] = useState(variants[0]?.id);
  const variant = variants.find((v) => v.id === variantId) ?? variants[0];
  const [activeImg, setActiveImg] = useState(0);
  const addItem = useCartStore((s) => s.addItem);
  const isLoading = useCartStore((s) => s.isLoading);

  const optionValues = useMemo(() => {
    const map: Record<string, Set<string>> = {};
    for (const v of variants) {
      for (const o of v.selectedOptions) {
        map[o.name] ??= new Set();
        map[o.name].add(o.value);
      }
    }
    return map;
  }, [variants]);

  const currentOptions: Record<string, string> = {};
  for (const o of variant?.selectedOptions ?? []) currentOptions[o.name] = o.value;

  const setOption = (name: string, value: string) => {
    const target = { ...currentOptions, [name]: value };
    const match = variants.find((v) => v.selectedOptions.every((o) => target[o.name] === o.value));
    if (match) setVariantId(match.id);
  };

  const handleAdd = async () => {
    if (!variant) return;
    await addItem({
      product: { node: product },
      variantId: variant.id,
      variantTitle: variant.title,
      price: variant.price,
      quantity: 1,
      selectedOptions: variant.selectedOptions || [],
    });
    toast.success("Added to bag", { description: product.title, position: "top-right" });
  };

  const images = product.images.edges;

  return (
    <div className="container-page py-8 md:py-12">
      <Link to="/products" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6">
        <ChevronLeft className="h-4 w-4" /> Back to shop
      </Link>
      <div className="grid gap-10 md:grid-cols-2">
        <div>
          <div className="aspect-square rounded-2xl overflow-hidden bg-muted">
            {images[activeImg] && (
              <img src={images[activeImg].node.url} alt={images[activeImg].node.altText ?? product.title} className="h-full w-full object-cover" />
            )}
          </div>
          {images.length > 1 && (
            <div className="mt-3 grid grid-cols-5 gap-2">
              {images.map((img, i) => (
                <button
                  key={img.node.url}
                  onClick={() => setActiveImg(i)}
                  className={`aspect-square rounded-lg overflow-hidden bg-muted border-2 transition ${i === activeImg ? "border-accent" : "border-transparent"}`}
                >
                  <img src={img.node.url} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="md:pt-2">
          <h1 className="font-display text-3xl md:text-4xl leading-tight">{product.title}</h1>
          <p className="mt-3 text-2xl font-medium tabular-nums">
            {variant && formatPrice(variant.price.amount, variant.price.currencyCode)}
          </p>

          {product.options.map((opt) => {
            if (opt.values.length <= 1 && opt.values[0] === "Default Title") return null;
            const values = Array.from(optionValues[opt.name] ?? []);
            return (
              <div key={opt.name} className="mt-6">
                <p className="text-sm font-medium mb-2">
                  {opt.name}: <span className="text-muted-foreground">{currentOptions[opt.name]}</span>
                </p>
                <div className="flex flex-wrap gap-2">
                  {values.map((v) => {
                    const active = currentOptions[opt.name] === v;
                    return (
                      <button
                        key={v}
                        onClick={() => setOption(opt.name, v)}
                        className={`px-4 py-2 rounded-full text-sm border transition-colors ${
                          active ? "bg-primary text-primary-foreground border-primary" : "border-border hover:border-foreground"
                        }`}
                      >
                        {v}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}

          <Button
            onClick={handleAdd}
            size="lg"
            className="w-full mt-8 rounded-full h-12"
            disabled={isLoading || !variant?.availableForSale}
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : (
              <><ShoppingBag className="w-4 h-4 mr-2" />{variant?.availableForSale === false ? "Sold out" : "Add to bag"}</>
            )}
          </Button>

          <div className="mt-6 grid grid-cols-3 gap-3 text-xs text-muted-foreground">
            <div className="flex items-center gap-2"><Truck className="h-4 w-4 text-accent" /> Worldwide shipping</div>
            <div className="flex items-center gap-2"><RefreshCcw className="h-4 w-4 text-accent" /> 30-day returns</div>
            <div className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-accent" /> Secure checkout</div>
          </div>

          {product.description && (
            <div className="mt-8 prose prose-sm max-w-none">
              <h2 className="font-display text-lg mb-2">Details</h2>
              <p className="text-sm text-muted-foreground whitespace-pre-line leading-relaxed">
                {product.description}
              </p>
            </div>
          )}

          <div className="mt-10 border-t border-border pt-6">
            <h2 className="font-display text-lg mb-1">Reviews</h2>
            <p className="text-sm text-muted-foreground">No reviews yet.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
