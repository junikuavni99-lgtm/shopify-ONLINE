import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms of Service — Everly Finds" },
      { name: "description", content: "The terms governing use of Everly Finds and its storefront." },
      { property: "og:title", content: "Terms of Service — Everly Finds" },
      { property: "og:description", content: "Terms of service for Everly Finds." },
    ],
  }),
  component: Terms,
});

function Terms() {
  return (
    <div className="container-page py-16 md:py-24 max-w-3xl space-y-6 text-muted-foreground leading-relaxed">
      <p className="text-xs uppercase tracking-[0.2em] text-accent">Legal</p>
      <h1 className="font-display text-4xl md:text-5xl text-foreground">Terms of Service</h1>
      <p>By using this site and placing an order you agree to these terms. Prices and availability are subject to change without notice. Orders are accepted when payment clears and inventory is confirmed by our fulfillment partner.</p>
      <p>Product photos are as accurate as we can make them but slight color and material variation is normal. If an item is materially different from what you ordered, our return policy applies.</p>
      <p>All content on this site — text, images, logos — is the property of Everly Finds or its licensors and may not be copied without permission.</p>
      <p>Questions about these terms? Email <a href="mailto:hello@everlyfinds.example" className="text-accent underline underline-offset-4">hello@everlyfinds.example</a>.</p>
    </div>
  );
}
