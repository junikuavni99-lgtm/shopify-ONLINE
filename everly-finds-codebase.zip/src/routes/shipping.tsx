import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/shipping")({
  head: () => ({
    meta: [
      { title: "Shipping & Returns — Everly Finds" },
      { name: "description", content: "Everly Finds shipping timelines, tracking, and 30-day return policy." },
      { property: "og:title", content: "Shipping & Returns — Everly Finds" },
      { property: "og:description", content: "Shipping timelines and 30-day return policy." },
    ],
  }),
  component: Shipping,
});

function Shipping() {
  return (
    <div className="container-page py-16 md:py-24 max-w-3xl space-y-10">
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-accent">Policies</p>
        <h1 className="font-display text-4xl md:text-5xl mt-3">Shipping & returns</h1>
      </div>
      <section>
        <h2 className="font-display text-2xl mb-3">Processing</h2>
        <p className="text-muted-foreground">Orders are prepared within 1–3 business days. You'll get an email with a tracking number as soon as your parcel ships.</p>
      </section>
      <section>
        <h2 className="font-display text-2xl mb-3">Delivery times</h2>
        <ul className="text-muted-foreground space-y-2 list-disc pl-5">
          <li>United States: 7–12 business days</li>
          <li>Europe: 8–14 business days</li>
          <li>Rest of world: 10–18 business days</li>
        </ul>
        <p className="text-sm text-muted-foreground mt-3">Times exclude customs delays. We ship through global fulfillment partners; occasional weather or carrier delays are outside our control, but we track every parcel and step in when something goes wrong.</p>
      </section>
      <section>
        <h2 className="font-display text-2xl mb-3">Returns</h2>
        <p className="text-muted-foreground">Return unused items in their original packaging within 30 days of delivery for a refund of the item price. Return shipping is customer-paid unless the item arrived defective — in which case we cover it and send a replacement.</p>
      </section>
      <section>
        <h2 className="font-display text-2xl mb-3">Damaged or wrong item?</h2>
        <p className="text-muted-foreground">Email hello@everlyfinds.example within 7 days with a photo and your order number and we'll make it right.</p>
      </section>
    </div>
  );
}
