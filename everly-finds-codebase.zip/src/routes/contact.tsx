import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Everly Finds" },
      { name: "description", content: "Get in touch with Everly Finds. We respond within one business day." },
      { property: "og:title", content: "Contact — Everly Finds" },
      { property: "og:description", content: "Get in touch — we respond within one business day." },
    ],
  }),
  component: Contact,
});

function Contact() {
  return (
    <div className="container-page py-16 md:py-24 max-w-2xl">
      <p className="text-xs uppercase tracking-[0.2em] text-accent">Say hello</p>
      <h1 className="font-display text-4xl md:text-5xl mt-3">Get in touch</h1>
      <p className="mt-4 text-muted-foreground">
        Questions, feedback, or a product idea? Email us at{" "}
        <a href="mailto:hello@everlyfinds.example" className="text-accent underline underline-offset-4">hello@everlyfinds.example</a>{" "}
        or send a note below. We respond within one business day.
      </p>
      <form className="mt-10 grid gap-4" onSubmit={(e) => e.preventDefault()}>
        <div className="grid sm:grid-cols-2 gap-4">
          <input required placeholder="Name" className="h-12 rounded-full border border-input bg-background px-5 text-sm outline-none focus:ring-2 focus:ring-ring" />
          <input required type="email" placeholder="Email" className="h-12 rounded-full border border-input bg-background px-5 text-sm outline-none focus:ring-2 focus:ring-ring" />
        </div>
        <input placeholder="Order number (optional)" className="h-12 rounded-full border border-input bg-background px-5 text-sm outline-none focus:ring-2 focus:ring-ring" />
        <textarea required rows={5} placeholder="How can we help?" className="rounded-2xl border border-input bg-background px-5 py-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
        <Button type="submit" size="lg" className="rounded-full w-fit">Send message</Button>
      </form>
    </div>
  );
}
