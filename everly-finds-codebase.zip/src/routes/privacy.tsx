import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — Everly Finds" },
      { name: "description", content: "How Everly Finds collects, uses, and protects your data." },
      { property: "og:title", content: "Privacy Policy — Everly Finds" },
      { property: "og:description", content: "How we handle your data at Everly Finds." },
    ],
  }),
  component: Privacy,
});

function Privacy() {
  return (
    <div className="container-page py-16 md:py-24 max-w-3xl space-y-6 text-muted-foreground leading-relaxed">
      <p className="text-xs uppercase tracking-[0.2em] text-accent">Legal</p>
      <h1 className="font-display text-4xl md:text-5xl text-foreground">Privacy Policy</h1>
      <p>We collect only the information needed to process your orders: name, shipping address, email, and payment details. Payment processing is handled by Shopify; we never see or store your full card number.</p>
      <p>We use your contact details to send order updates and, if you opt in, occasional emails about new products. You can unsubscribe from marketing at any time using the link at the bottom of any email.</p>
      <p>We do not sell your personal information. We share it only with the third parties required to fulfill your order — payment processors, shipping carriers, and fulfillment partners — and only what they need to do their job.</p>
      <p>For requests to access, correct, or delete your data, email <a href="mailto:privacy@everlyfinds.example" className="text-accent underline underline-offset-4">privacy@everlyfinds.example</a>.</p>
    </div>
  );
}
