import { Link } from "@tanstack/react-router";
import { CartDrawer } from "./CartDrawer";

export function Header() {
  return (
    <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container-page flex items-center justify-between h-16">
        <Link to="/" className="flex items-center gap-2">
          <span className="inline-block h-7 w-7 rounded-full bg-accent" aria-hidden />
          <span className="font-display text-xl tracking-tight">Everly Finds</span>
        </Link>
        <nav className="hidden md:flex items-center gap-8 text-sm">
          <Link to="/" className="hover:text-accent transition-colors">Home</Link>
          <Link to="/products" className="hover:text-accent transition-colors">Shop</Link>
          <Link to="/products" search={{ q: "pet" }} className="hover:text-accent transition-colors">Pets</Link>
          <Link to="/products" search={{ q: "fitness" }} className="hover:text-accent transition-colors">Fitness</Link>
          <Link to="/about" className="hover:text-accent transition-colors">About</Link>
        </nav>
        <div className="flex items-center gap-1">
          <CartDrawer />
        </div>
      </div>
    </header>
  );
}
